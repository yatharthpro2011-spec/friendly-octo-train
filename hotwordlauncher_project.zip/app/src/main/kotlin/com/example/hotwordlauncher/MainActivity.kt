package com.example.hotwordlauncher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var statusText: TextView

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startHotwordService()
            else statusText.text = "Microphone permission is required"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        val startBtn: Button = findViewById(R.id.startBtn)
        val stopBtn: Button = findViewById(R.id.stopBtn)

        startBtn.setOnClickListener {
            ensurePermissionsAndStart()
        }

        stopBtn.setOnClickListener {
            stopService(Intent(this, HotwordService::class.java))
            statusText.text = "Hotword listener stopped"
        }
    }

    private fun ensurePermissionsAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else startHotwordService()
    }

    private fun startHotwordService() {
        val svc = Intent(this, HotwordService::class.java)
        ContextCompat.startForegroundService(this, svc)
        statusText.text = "Hotword listener running"
    }
}
