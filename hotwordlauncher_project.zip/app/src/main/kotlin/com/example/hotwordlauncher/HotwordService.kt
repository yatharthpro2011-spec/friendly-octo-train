package com.example.hotwordlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import java.util.*
import android.os.Bundle
import java.util.Locale

class HotwordService : Service() {
    private var speechRecognizer: SpeechRecognizer? = null
    private var recognizerIntent: Intent? = null

    private val CHANNEL_ID = "hotword_listener"
    private val NOTIF_ID = 101

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        initSpeechRecognizer()
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Hotword Listener", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Hotword listener")
            .setContentText("Listening for hotwords: 'Alexa', 'Hey Google'")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
        return builder.build()
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                // restart listening after small delay
                restartListening()
            }

            override fun onResults(results: Bundle?) {
                handleResults(results)
                restartListening()
            }

            override fun onPartialResults(partialResults: Bundle?) {
                handleResults(partialResults)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        startListening()
    }

    private fun startListening() {
        try {
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            // ignore and try restart
            restartListening()
        }
    }

    private fun restartListening() {
        try {
            speechRecognizer?.cancel()
            // small delay to avoid quick crash loop
            val t = Timer()
            t.schedule(object : TimerTask() {
                override fun run() {
                    startListening()
                }
            }, 300)
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun handleResults(bundle: Bundle?) {
        val matches = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (matches.isEmpty()) return
        val text = matches.joinToString(" ").lowercase(Locale.getDefault())

        if (text.contains("alexa")) {
            launchAlexa()
        } else if (text.contains("hey google") || text.contains("ok google")) {
            launchGoogleAssistant()
        }
    }

    private fun launchAlexa() {
        val pm = packageManager
        val intent = pm.getLaunchIntentForPackage("com.amazon.dee.app")
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    private fun launchGoogleAssistant() {
        // Try standard assistant action
        try {
            val assist = Intent(Intent.ACTION_VOICE_COMMAND)
            assist.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(assist)
        } catch (e: Exception) {
            // fallback: open google app
            val pm = packageManager
            val intent = pm.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
        }
    }
}
